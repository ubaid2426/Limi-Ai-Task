package com.task.gateway_service.dto;

import lombok.Data;

@Data
public class AiRequestDto {
    private String prompt;
}

