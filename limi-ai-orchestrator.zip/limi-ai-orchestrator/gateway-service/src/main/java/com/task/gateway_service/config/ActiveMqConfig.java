package com.task.gateway_service.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.support.converter.MappingJackson2MessageConverter;
import org.springframework.jms.support.converter.MessageType;

import java.util.Map;

@Configuration
public class ActiveMqConfig {

    @Bean
    public MappingJackson2MessageConverter converter() {
        MappingJackson2MessageConverter c = new MappingJackson2MessageConverter();
        c.setTargetType(MessageType.TEXT);

        // send simple class name only
        c.setTypeIdPropertyName("_type");
        c.setTypeIdMappings(Map.of(
                "AiRequestMessage", com.task.gateway_service.dto.AiRequestMessage.class
        ));

        return c;
    }
}
