package com.task.gateway_service.messaging;

import com.task.gateway_service.dto.AiRequestMessage;
import lombok.RequiredArgsConstructor;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AiMessageProducer {

    private final JmsTemplate jmsTemplate;

    @Value("${queue.ai}")
    private String queue;

    public void send(AiRequestMessage msg) {
        jmsTemplate.convertAndSend(queue, msg);
    }
}

