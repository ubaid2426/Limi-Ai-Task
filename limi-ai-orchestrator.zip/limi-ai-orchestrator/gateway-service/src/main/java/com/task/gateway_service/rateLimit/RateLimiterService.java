package com.task.gateway_service.rateLimit;

import com.task.gateway_service.exception.TooManyRequestsException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class RateLimiterService {

    private final Map<String, List<Long>> map = new ConcurrentHashMap<>();

    public void validate(String user) {

        long now = System.currentTimeMillis();
        map.putIfAbsent(user, new ArrayList<>());
        List<Long> times = map.get(user);

        times.removeIf(t -> now - t > 60000);

        if (times.size() >= 5)
            throw new TooManyRequestsException();

        times.add(now);
    }
}

