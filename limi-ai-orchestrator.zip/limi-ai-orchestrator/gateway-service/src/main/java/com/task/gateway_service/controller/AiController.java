package com.task.gateway_service.controller;

import com.task.gateway_service.dto.AiRequestDto;
import com.task.gateway_service.dto.AiRequestMessage;
import com.task.gateway_service.messaging.AiMessageProducer;
import com.task.gateway_service.rateLimit.RateLimiterService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/ai")
@RequiredArgsConstructor
public class AiController {

    private final AiMessageProducer producer;
    private final RateLimiterService rateLimiter;

    @PostMapping("/ask")
    public ResponseEntity<String> ask(@RequestBody AiRequestDto dto,
                                      Authentication auth) {

        // Validate prompt
        if (dto.getPrompt() == null || dto.getPrompt().isBlank()) {
            throw new IllegalArgumentException("Prompt cannot be empty");
        }

        String user = auth.getName();

        rateLimiter.validate(user); // Throws exception if limit exceeded

        producer.send(new AiRequestMessage(user, dto.getPrompt()));

        return ResponseEntity.accepted().body("Request queued");
    }
}