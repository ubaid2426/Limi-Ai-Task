package com.task.gateway_service.exception;


public class TooManyRequestsException extends RuntimeException {
    public TooManyRequestsException() {
        super("Rate limit exceeded: only 5 AI requests per minute allowed");
    }
}

