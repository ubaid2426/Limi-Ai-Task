import { useEffect, useState } from 'react'
import './App.css'
import axios from 'axios'
const API_BASE = 'https://unattractive-costlier-archie.ngrok-free.dev'
const api = axios.create({
  baseURL: API_BASE,
})

// Add request interceptor to attach token to all requests
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('jwt');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }

    // Add ngrok header
    config.headers['ngrok-skip-browser-warning'] = 'true';

    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);
function App() {

  
  const [token, setToken] = useState(() => localStorage.getItem('jwt') || '')
  const [activeTab, setActiveTab] = useState(() =>
    localStorage.getItem('jwt') ? 'chat' : 'login',
  )
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [isLoggingIn, setIsLoggingIn] = useState(false)
  const [loginError, setLoginError] = useState('')

  const [prompt, setPrompt] = useState('')
  const [aiResponse, setAiResponse] = useState('')
  const [isAsking, setIsAsking] = useState(false)
  const [askError, setAskError] = useState('')
  const [history, setHistory] = useState([])

  const [stats, setStats] = useState(null)
  const [logs, setLogs] = useState([])
  const [adminLoading, setAdminLoading] = useState(false)
  const [adminError, setAdminError] = useState('')

  useEffect(() => {
    if (!token && activeTab !== 'login') {
      setActiveTab('login')
    }
  }, [token, activeTab])

  const handleLogin = async (e) => {
    e.preventDefault()
    setIsLoggingIn(true)
    setLoginError('')
  
    try {
      const res = await axios.post(
        `${API_BASE}/auth/login`,
        null, // no body
        {
          params: {
            username: username,
          },
        }
      )
  
      const receivedToken = res.data?.token
      if (!receivedToken) {
        throw new Error('Token not found in response')
      }
  
      setToken(receivedToken)
      localStorage.setItem('jwt', receivedToken)
      setActiveTab('chat')
  
    } catch (err) {
      if (err.response) {
        setLoginError(err.response.data?.message || 'Login failed')
      } else if (err.request) {
        setLoginError('No response from server')
      } else {
        setLoginError(err.message || 'Unable to login')
      }
    } finally {
      setIsLoggingIn(false)
    }
  }
  const handleLogout = () => {
    setToken('')
    localStorage.removeItem('jwt')
    setPrompt('')
    setAiResponse('')
    setHistory([])
  }

  const handleAsk = async (e) => {
    e.preventDefault()
    if (!prompt.trim()) return
    if (!token) {
      setAskError('Please login first.')
      return
    }

    setIsAsking(true)
    setAskError('')

    const currentPrompt = prompt.trim()

    try {
      const res = await api.post(`${API_BASE}/ai/ask`, {
        prompt : currentPrompt
      })

      const data = res.data
      let responseText = ''

      if (typeof data === 'string') {
        responseText = data
      } else if (data) {
        responseText = data.response || data.answer || JSON.stringify(data)
      } else {
        responseText = 'No response received.'
      }

      setAiResponse(responseText)
      setHistory((prev) => [
        { prompt: currentPrompt, response: responseText, time: new Date().toISOString() },
        ...prev,
      ])
    } catch (err) {
      setAskError(err.message || 'Something went wrong.')
    } finally {
      setIsAsking(false)
    }
  }

  const loadAdminData = async () => {
    if (!token) {
      setAdminError('Not authenticated')
      return
    }
  
    setAdminLoading(true)
    setAdminError('')
  
    try {
      const statsRes = await api.get(`${API_BASE}/admin/stats`)
      const logsRes = await api.get(`${API_BASE}/admin/logs`)
  
      setStats(statsRes.data)
      setLogs(Array.isArray(logsRes.data) ? logsRes.data : [])
  
    } catch (err) {
      console.error('Admin error:', err)
   
      if (err.response?.status === 401) {
        setAdminError('Unauthorized. Please login again.')
      } else if (err.response?.status === 403) {
        setAdminError('Access denied. Admin role required.')
      } else if (err.response?.status === 405) {
        setAdminError('Wrong HTTP method on backend.')
      } else {
        setAdminError(
          err.response?.data?.message ||
          err.message ||
          'Unable to load admin data'
        )
      }
    } finally {
      setAdminLoading(false)
    }
  }
  useEffect(() => {
    if (activeTab === 'admin') {
      loadAdminData()
    }
  }, [activeTab])

  return (
    <div className="min-h-screen bg-slate-950 text-slate-50 flex flex-col">
      <div className="absolute inset-0 -z-10 overflow-hidden">
        <div className="pointer-events-none absolute -left-32 top-0 h-72 w-72 rounded-full bg-indigo-500/40 blur-3xl" />
        <div className="pointer-events-none absolute right-0 top-40 h-80 w-80 rounded-full bg-emerald-500/30 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-16 left-1/2 h-72 w-72 -translate-x-1/2 rounded-full bg-cyan-500/30 blur-3xl" />
      </div>

      <header className="border-b border-white/5 bg-slate-950/80 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-4">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-500 via-sky-500 to-emerald-400 text-lg font-semibold shadow-lg shadow-sky-500/40">
              L
            </div>
            <div>
              <p className="text-sm font-semibold tracking-tight text-slate-50">
                Limi AI Gateway
              </p>
              <p className="text-xs text-slate-400">
                Secure, audited AI access layer
              </p>
            </div>
          </div>

          <nav className="flex items-center gap-1 rounded-full border border-white/10 bg-slate-900/70 p-1 text-xs font-medium text-slate-300 shadow-lg shadow-black/40">
            <button
              type="button"
              onClick={() => setActiveTab('login')}
              className={`px-4 py-1.5 rounded-full transition-all ${
                activeTab === 'login'
                  ? 'bg-slate-100 text-slate-900 shadow-sm'
                  : 'hover:bg-slate-800/80'
              }`}
            >
              Login
            </button>
            {token && (
              <>
                <button
                  type="button"
                  onClick={() => setActiveTab('chat')}
                  className={`px-4 py-1.5 rounded-full transition-all ${
                    activeTab === 'chat'
                      ? 'bg-slate-100 text-slate-900 shadow-sm'
                      : 'hover:bg-slate-800/80'
                  }`}
                >
                  AI Gateway
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('admin')}
                  className={`px-4 py-1.5 rounded-full transition-all ${
                    activeTab === 'admin'
                      ? 'bg-slate-100 text-slate-900 shadow-sm'
                      : 'hover:bg-slate-800/80'
                  }`}
                >
                  Admin Dashboard
                </button>
              </>
            )}
          </nav>

          <div className="flex items-center gap-3">
            {token ? (
              <>
                <span className="hidden text-xs text-slate-300 sm:inline">
                  Authenticated
                </span>
                <button
                  type="button"
                  onClick={handleLogout}
                  className="rounded-full border border-white/15 bg-slate-900/80 px-3 py-1 text-xs font-medium text-slate-100 hover:bg-slate-800 active:scale-[0.98] transition"
                >
                  Log out
                </button>
              </>
            ) : (
              <span className="text-xs text-slate-400">
                Not authenticated
              </span>
            )}
          </div>
        </div>
      </header>

      <main className="mx-auto flex w-full max-w-6xl flex-1 flex-col gap-6 px-4 py-6 pb-10">
        {activeTab === 'login' && (
          <section className="flex flex-1 items-center justify-center">
            <div className="w-full max-w-md rounded-3xl border border-white/10 bg-slate-900/80 p-6 shadow-2xl shadow-black/60">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <h2 className="text-sm font-semibold tracking-tight text-slate-50">
                    Authentication
                  </h2>
                  <p className="mt-1 text-xs text-slate-400">
                    Use your username to obtain a JWT from the gateway service.
                  </p>
                </div>
                <span className="rounded-full bg-emerald-500/10 px-3 py-1 text-[11px] font-medium text-emerald-300 ring-1 ring-emerald-400/30">
                  JWT Secured
                </span>
              </div>

              <form
                onSubmit={handleLogin}
                className="mt-4 flex flex-col gap-4"
              >
                  <div className="flex-1 min-w-[160px]">
                  <label
                    htmlFor="username"
                    className="text-xs font-medium text-slate-300"
                  >
                      Username
                  </label>
                  <input
                    id="username"
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    required
                    placeholder="e.g. ubaid"
                    className="mt-1 w-full rounded-xl border border-white/10 bg-slate-950/60 px-3 py-2 text-sm text-slate-50 shadow-inner shadow-black/40 outline-none placeholder:text-slate-500 focus:border-sky-400 focus:ring-2 focus:ring-sky-500/40"
                  />
                </div>
                  {/* <div className="flex-1 min-w-[160px]">
                    <label
                      htmlFor="password"
                      className="text-xs font-medium text-slate-300"
                    >
                      Password
                    </label>
                    <input
                      id="password"
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                      placeholder="Enter your password"
                      className="mt-1 w-full rounded-xl border border-white/10 bg-slate-950/60 px-3 py-2 text-sm text-slate-50 shadow-inner shadow-black/40 outline-none placeholder:text-slate-500 focus:border-sky-400 focus:ring-2 focus:ring-sky-500/40"
                    />
                  </div> */}
                <button
                  type="submit"
                  disabled={isLoggingIn}
                  className="inline-flex items-center justify-center rounded-xl bg-gradient-to-r from-sky-500 via-indigo-500 to-emerald-400 px-4 py-2 text-xs font-semibold text-slate-950 shadow-lg shadow-sky-500/40 transition hover:brightness-110 disabled:opacity-60"
                >
                  {isLoggingIn ? 'Authenticating…' : token ? 'Re-issue Token' : 'Login'}
                </button>
              </form>

              {loginError && (
                <p className="mt-3 text-xs text-red-400">{loginError}</p>
              )}
              {token && !loginError && (
                <p className="mt-3 text-xs text-emerald-300">
                  Token active. Switched to AI Gateway — you can now send prompts.
                </p>
              )}
            </div>
          </section>
        )}

        {activeTab === 'chat' && (
          <section className="grid gap-6 lg:grid-cols-[minmax(0,2fr)_minmax(0,1.4fr)]">
            <div className="space-y-4">
              <div className="rounded-3xl border border-white/10 bg-slate-900/80 p-5 shadow-xl shadow-black/40">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <h2 className="text-sm font-semibold tracking-tight text-slate-50">
                      Ask the AI
                    </h2>
                    <p className="mt-1 text-xs text-slate-400">
                      All requests are queued, rate-limited (5/min per user), and fully logged.
                    </p>
                  </div>
                  <span className="rounded-full bg-sky-500/10 px-3 py-1 text-[11px] font-medium text-sky-300 ring-1 ring-sky-400/40">
                    Resilient Gateway
                  </span>
                </div>

                <form onSubmit={handleAsk} className="mt-4 space-y-3">
                  <textarea
                    rows={4}
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    placeholder="Explain microservices in detail, compare with monoliths, and describe typical architecture patterns…"
                    className="w-full resize-none rounded-2xl border border-white/10 bg-slate-950/60 px-3 py-2 text-sm text-slate-50 shadow-inner shadow-black/40 outline-none placeholder:text-slate-500 focus:border-sky-400 focus:ring-2 focus:ring-sky-500/40"
                  />
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <p className="text-[11px] text-slate-400">
                      The backend decides when to offload to the queue and stores every call in the audit log.
                    </p>
                    <button
                      type="submit"
                      disabled={isAsking || !token}
                      className="inline-flex items-center justify-center gap-2 rounded-xl bg-sky-500 px-4 py-2 text-xs font-semibold text-slate-950 shadow-lg shadow-sky-500/40 transition hover:bg-sky-400 disabled:cursor-not-allowed disabled:opacity-60"
                    >
                      {isAsking && (
                        <span className="h-3 w-3 animate-spin rounded-full border-2 border-slate-900 border-t-transparent" />
                      )}
                      {isAsking ? 'Waiting for AI…' : 'Send to AI'}
                    </button>
                  </div>
                </form>

                {askError && (
                  <p className="mt-3 text-xs text-red-400">{askError}</p>
                )}

                {aiResponse && !askError && (
                  <div className="mt-5 rounded-2xl border border-white/10 bg-slate-950/70 p-4 text-sm leading-relaxed text-slate-100">
                    <div className="mb-2 flex items-center justify-between text-[11px] text-slate-400">
                      <span>AI Response</span>
                      <span className="rounded-full bg-emerald-500/10 px-2 py-0.5 text-[10px] text-emerald-300">
                        Latest
                      </span>
                    </div>
                    <p className="whitespace-pre-wrap">{aiResponse}</p>
                  </div>
                )}
              </div>
            </div>

            <aside className="space-y-4">
              <div className="rounded-3xl border border-white/10 bg-slate-900/70 p-4 shadow-xl shadow-black/40">
                <h3 className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-400">
                  Request History
                </h3>
                <p className="mt-1 text-xs text-slate-400">
                  All prompts and responses are also persisted by the backend for full auditing.
                </p>
                <div className="mt-4 max-h-[420px] space-y-3 overflow-y-auto pr-1 text-xs">
                  {history.length === 0 && (
                    <p className="text-slate-500">
                      No prompts yet. Send your first microservice question to populate history.
                    </p>
                  )}
                  {history.map((item, idx) => (
                    <div
                      key={`${item.time}-${idx}`}
                      className="rounded-2xl border border-white/5 bg-slate-950/70 p-3"
                    >
                      <p className="text-[10px] text-slate-500">
                        {new Date(item.time).toLocaleTimeString()}
                      </p>
                      <p className="mt-1 text-[11px] font-semibold text-slate-200">
                        You
                      </p>
                      <p className="mt-1 text-[11px] text-slate-300">
                        {item.prompt}
                      </p>
                      <p className="mt-2 text-[11px] font-semibold text-emerald-300">
                        AI
                      </p>
                      <p className="mt-1 text-[11px] text-slate-200 line-clamp-4">
                        {item.response}
                      </p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="rounded-3xl border border-amber-400/20 bg-amber-500/10 p-4 text-xs text-amber-50 shadow-xl shadow-amber-500/30">
                <p className="font-semibold">Rate limiting</p>
                <p className="mt-1 text-amber-100/80">
                  The gateway limits each user to <span className="font-semibold">5 requests per minute</span>.
                  When exceeded, you will see a 429 message and the backend will log the quota breach.
                </p>
              </div>
            </aside>
          </section>
        )}

        {activeTab === 'admin' && (
          <section className="space-y-5">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h2 className="text-sm font-semibold tracking-tight text-slate-50">
                  Admin Observability
                </h2>
                <p className="mt-1 text-xs text-slate-400">
                  Live statistics and audit logs pulled directly from the microservice database.
                </p>
              </div>
              <button
                type="button"
                onClick={loadAdminData}
                className="inline-flex items-center gap-2 rounded-xl border border-white/15 bg-slate-900/80 px-3 py-1.5 text-xs font-medium text-slate-100 hover:bg-slate-800 active:scale-[0.98] transition"
              >
                <span className="h-3 w-3 rounded-full bg-emerald-400/80 shadow shadow-emerald-500/60" />
                Refresh data
              </button>
            </div>

            {adminError && (
              <p className="text-xs text-red-400">{adminError}</p>
            )}

            <div className="grid gap-4 md:grid-cols-4">
              <div className="rounded-3xl border border-white/10 bg-slate-900/80 p-4 shadow-lg shadow-black/40">
                <p className="text-[11px] text-slate-400">Total Calls</p>
                <p className="mt-2 text-2xl font-semibold text-slate-50">
                  {stats ? stats.totalCalls : adminLoading ? '…' : '—'}
                </p>
              </div>
              <div className="rounded-3xl border border-white/10 bg-slate-900/80 p-4 shadow-lg shadow-black/40">
                <p className="text-[11px] text-slate-400">Success</p>
                <p className="mt-2 text-2xl font-semibold text-emerald-400">
                  {stats ? stats.successCalls : adminLoading ? '…' : '—'}
                </p>
              </div>
              <div className="rounded-3xl border border-white/10 bg-slate-900/80 p-4 shadow-lg shadow-black/40">
                <p className="text-[11px] text-slate-400">Failed</p>
                <p className="mt-2 text-2xl font-semibold text-rose-400">
                  {stats ? stats.failedCalls : adminLoading ? '…' : '—'}
                </p>
              </div>
              <div className="rounded-3xl border border-white/10 bg-slate-900/80 p-4 shadow-lg shadow-black/40">
                <p className="text-[11px] text-slate-400">Today</p>
                <p className="mt-2 text-2xl font-semibold text-sky-400">
                  {stats ? stats.todayCalls : adminLoading ? '…' : '—'}
                </p>
              </div>
            </div>

            <div className="rounded-3xl border border-white/10 bg-slate-900/80 p-4 shadow-xl shadow-black/40">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <h3 className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-400">
                    Audit Log
                  </h3>
                  <p className="mt-1 text-[11px] text-slate-500">
                    Raw view of the `ai_audit_logs` table exposed as a REST endpoint.
                  </p>
                </div>
                {adminLoading && (
                  <span className="h-3 w-3 animate-spin rounded-full border-2 border-slate-500 border-t-transparent" />
                )}
              </div>

              <div className="mt-3 max-h-[420px] overflow-auto rounded-2xl border border-white/5 bg-slate-950/70">
                <table className="min-w-full border-separate border-spacing-y-1 text-xs">
                  <thead className="sticky top-0 bg-slate-950/90 backdrop-blur">
                    <tr className="text-[11px] text-slate-400">
                      <th className="px-3 py-2 text-left font-medium">ID</th>
                      <th className="px-3 py-2 text-left font-medium">
                        User
                      </th>
                      <th className="px-3 py-2 text-left font-medium">
                        Prompt
                      </th>
                      <th className="px-3 py-2 text-left font-medium">
                        Response
                      </th>
                      <th className="px-3 py-2 text-left font-medium">
                        Status
                      </th>
                      <th className="px-3 py-2 text-left font-medium">
                        Created At
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {logs.length === 0 && !adminLoading && (
                      <tr>
                        <td
                          colSpan={6}
                          className="px-3 py-4 text-center text-slate-500"
                        >
                          No logs available.
                        </td>
                      </tr>
                    )}
                    {logs.map((row) => (
                      <tr
                        key={row.id}
                        className="align-top text-[11px] text-slate-200"
                      >
                        <td className="px-3 py-2 text-slate-400">
                          {row.id}
                        </td>
                        <td className="px-3 py-2 text-slate-200">
                          {row.username}
                        </td>
                        <td className="max-w-xs px-3 py-2 text-slate-200">
                          <div className="line-clamp-3">{row.prompt}</div>
                        </td>
                        <td className="max-w-xs px-3 py-2 text-slate-300">
                          <div className="line-clamp-3">
                            {row.response}
                          </div>
                        </td>
                        <td className="px-3 py-2">
                          <span
                            className={`inline-flex rounded-full px-2 py-0.5 text-[10px] font-semibold ${
                              row.status === 'SUCCESS'
                                ? 'bg-emerald-500/10 text-emerald-300 ring-1 ring-emerald-500/40'
                                : 'bg-rose-500/10 text-rose-300 ring-1 ring-rose-500/40'
                            }`}
                          >
                            {row.status}
                          </span>
                        </td>
                        <td className="px-3 py-2 text-slate-400">
                          {row.createdAt
                            ? new Date(row.createdAt).toLocaleString()
                            : '—'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </section>
        )}
      </main>
    </div>
  )
}

export default App