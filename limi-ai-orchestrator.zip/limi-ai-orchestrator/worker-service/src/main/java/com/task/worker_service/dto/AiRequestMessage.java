package com.task.worker_service.dto;

//package com.task.worker_service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AiRequestMessage implements Serializable {
    private String username;
    private String prompt;
}

