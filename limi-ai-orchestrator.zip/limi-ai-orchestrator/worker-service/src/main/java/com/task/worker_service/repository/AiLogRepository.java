package com.task.worker_service.repository;

import com.task.worker_service.entity.AiLog;
import com.task.worker_service.entity.AiStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDateTime;

public interface AiLogRepository extends JpaRepository<AiLog, Long> {

    long countByStatus(AiStatus status);

    long countByCreatedAtBetween(LocalDateTime start, LocalDateTime end);
}