package com.task.worker_service.consumer;

import com.task.worker_service.dto.AiRequestMessage;
import com.task.worker_service.service.AiProcessingService;
import lombok.RequiredArgsConstructor;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class AiRequestConsumer {

    private final AiProcessingService service;

    @JmsListener(destination = "${queue.ai}")
    public void receive(AiRequestMessage msg) {
        service.process(msg);
    }
}

