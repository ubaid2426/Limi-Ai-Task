//package com.task.worker_service.ai;
//
//import lombok.RequiredArgsConstructor;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.http.*;
//import org.springframework.stereotype.Service;
//import org.springframework.web.client.HttpClientErrorException;
//import org.springframework.web.client.RestTemplate;
//
//import java.util.List;
//import java.util.Map;
//
//@Service
//@RequiredArgsConstructor
//public class ExternalAiClient {
//
//    @Value("${ai.api-key}")
//    private String apiKey;
//
//    @Value("${ai.url}")
//    private String url;
//
//    private final RestTemplate rest = new RestTemplate();
//
//    public String askAi(String prompt) {
//
//        String fullUrl = url + "?key=" + apiKey;
//
//        HttpHeaders headers = new HttpHeaders();
//        headers.setContentType(MediaType.APPLICATION_JSON);
//
//        Map<String, Object> body = Map.of(
//                "contents", List.of(
//                        Map.of(
//                                "parts", List.of(
//                                        Map.of("text", prompt)
//                                )
//                        )
//                )
//        );
//
//        HttpEntity<?> request = new HttpEntity<>(body, headers);
//
//        try {
//
//            String response = rest.postForObject(fullUrl, request, String.class);
//
//            if (response == null || response.isBlank()) {
//                throw new RuntimeException("Empty AI response");
//            }
//
//            if (response.contains("RESOURCE_EXHAUSTED")
//                    || response.contains("Quota exceeded")) {
//
//                throw new RuntimeException("AI quota exceeded (provider limit).");
//            }
//
//            return response;
//
//        } catch (HttpClientErrorException.TooManyRequests e) {
//
//
//            throw new RuntimeException("AI quota exceeded (provider limit).");
//
//        } catch (HttpClientErrorException e) {
//
//
//            throw new RuntimeException(
//                    "HTTP Error: " + e.getStatusCode().value() + " - " + e.getStatusText()
//            );
//
//        } catch (Exception e) {
//
//            throw new RuntimeException("AI call failed: " + e.getMessage());
//        }
//    }
//
//}




package com.task.worker_service.ai;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Pattern;

@Slf4j
@Service
@RequiredArgsConstructor
public class ExternalAiClient {

    @Value("${ai.provider:gemini}")
    private String provider;

    @Value("${ai.api-key:}")
    private String apiKey;

    @Value("${ai.url:https://text.pollinations.ai}")
    private String url;

    @Value("${ai.pollinations.model:openai}")
    private String pollinationsModel;

    @Value("${ai.pollinations.temperature:0.7}")
    private String pollinationsTemperature;

    @Value("${ai.pollinations.system:You are a helpful assistant}")
    private String pollinationsSystem;

    @Value("${ai.pollinations.max-retries:3}")
    private int maxRetries;

    @Value("${ai.pollinations.retry-delay-ms:2000}")
    private int retryDelayMs;

    @Value("${ai.fallback-provider:gemini}")
    private String fallbackProvider;

    private final RestTemplate rest = new RestTemplate();
    private final ObjectMapper objectMapper = new ObjectMapper();

    // Simple rate limiter
    private final ConcurrentHashMap<String, AtomicInteger> requestCounts = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, Instant> rateLimitReset = new ConcurrentHashMap<>();

    /**
     * Ask AI with the given prompt using the configured provider
     */
    public String askAi(String prompt) {
        return askAiWithRetry(prompt, 0);
    }

    /**
     * Ask AI with retry logic
     */
    private String askAiWithRetry(String prompt, int retryCount) {
        try {
            // Check rate limits before making request
            if (isRateLimited()) {
                log.warn("Rate limit reached, waiting before retry...");
                Thread.sleep(retryDelayMs);
                return askAiWithRetry(prompt, retryCount);
            }

            String response = switch (provider.toLowerCase()) {
                case "pollinations", "pollinations.ai" -> askPollinations(prompt);
                case "gemini" -> askGemini(prompt);
                default -> throw new RuntimeException("Unknown AI provider: " + provider);
            };

            // Track successful request
            trackRequest();

            // Extract only the actual answer without reasoning_content
            String cleanResponse = extractActualAnswer(response);
            log.debug("Cleaned response: {}", cleanResponse);

            return cleanResponse;

        } catch (HttpClientErrorException.TooManyRequests e) {
            log.warn("Rate limited (429) on attempt {}/{}", retryCount + 1, maxRetries);

            // Track rate limit hit
            handleRateLimit();

            if (retryCount < maxRetries - 1) {
                // Exponential backoff
                long waitTime = retryDelayMs * (long) Math.pow(2, retryCount);
                log.info("Waiting {}ms before retry...", waitTime);

                try {
                    Thread.sleep(waitTime);
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                }

                return askAiWithRetry(prompt, retryCount + 1);
            } else {
                // Try fallback provider if configured
                if (fallbackProvider != null && !fallbackProvider.equals(provider)) {
                    log.info("Switching to fallback provider: {}", fallbackProvider);
                    return askAiWithFallback(prompt);
                }
                throw new RuntimeException("Rate limit exceeded after " + maxRetries + " retries");
            }

        } catch (Exception e) {
            log.error("Error in AI call", e);
            throw new RuntimeException("AI call failed: " + e.getMessage());
        }
    }

    /**
     * Extract only the actual answer from the response, removing reasoning_content
     */
    private String extractActualAnswer(String response) {
        if (response == null || response.isBlank()) {
            return "";
        }

        try {
            // Try to parse as JSON
            JsonNode root = objectMapper.readTree(response);

            // Check if it has role and reasoning_content (Pollinations format)
            if (root.has("role") && "assistant".equals(root.get("role").asText())) {

                // Create a new JSON object without reasoning_content
                ObjectNode cleanJson = objectMapper.createObjectNode();
                cleanJson.put("role", "assistant");

                // Copy only the fields we want (exclude reasoning_content)
                if (root.has("content")) {
                    cleanJson.put("content", root.get("content").asText());
                }

                if (root.has("tool_calls")) {
                    cleanJson.set("tool_calls", root.get("tool_calls"));
                }

                // Convert back to string
                return objectMapper.writeValueAsString(cleanJson);
            }

            // If it's not in that format, return as is
            return response;

        } catch (Exception e) {
            log.debug("Response is not JSON or couldn't be parsed, returning as-is: {}", e.getMessage());

            // Try regex approach as fallback
            return removeReasoningContentWithRegex(response);
        }
    }

    /**
     * Remove reasoning_content using regex (fallback method)
     */
    private String removeReasoningContentWithRegex(String response) {
        if (response == null || response.isBlank()) {
            return response;
        }

        // Pattern to match reasoning_content field and its value
        Pattern pattern = Pattern.compile("\"reasoning_content\":\"[^\"]*\",?");
        String cleaned = pattern.matcher(response).replaceAll("");

        // Also clean up any double commas or formatting issues
        cleaned = cleaned.replaceAll(",\\s*,", ",");
        cleaned = cleaned.replaceAll("\\{\\s*,", "{");
        cleaned = cleaned.replaceAll(",\\s*\\}", "}");

        return cleaned;
    }

    /**
     * Alternative method that returns only the content field if present
     */
    public String extractContentOnly(String response) {
        try {
            JsonNode root = objectMapper.readTree(response);

            // If it has content field, return just that
            if (root.has("content")) {
                return root.get("content").asText();
            }

            // If it has message field (common in some APIs)
            if (root.has("message")) {
                JsonNode message = root.get("message");
                if (message.has("content")) {
                    return message.get("content").asText();
                }
            }

            // Return the whole response if we can't extract content
            return response;

        } catch (Exception e) {
            return response;
        }
    }

    /**
     * Pollinations.AI integration
     */
    private String askPollinations(String prompt) {
        try {
            String encodedPrompt = encodePrompt(prompt);

            // Build URL with query parameters
            UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url + "/" + encodedPrompt);

            // Add parameters
            builder.queryParam("model", pollinationsModel)
                    .queryParam("temperature", pollinationsTemperature)
                    .queryParam("json", "true");  // Request JSON format

            if (pollinationsSystem != null && !pollinationsSystem.isEmpty()) {
                builder.queryParam("system", encodePrompt(pollinationsSystem));
            }

            String fullUrl = builder.toUriString();

            log.debug("Calling Pollinations.AI with URL: {}", fullUrl);

            // Add delay between requests to avoid rate limiting
            Thread.sleep(100);

            // Make request
            HttpHeaders headers = new HttpHeaders();
            headers.set("User-Agent", "Worker-Service/1.0");
            headers.set("Accept", "application/json");

            HttpEntity<?> entity = new HttpEntity<>(headers);

            ResponseEntity<String> response = rest.exchange(
                    fullUrl,
                    HttpMethod.GET,
                    entity,
                    String.class
            );

            String responseBody = response.getBody();

            if (responseBody == null || responseBody.isBlank()) {
                throw new RuntimeException("Empty AI response from Pollinations");
            }

            // Check if response contains rate limit message
            if (responseBody.contains("429") || responseBody.contains("Too Many Requests")) {
                throw HttpClientErrorException.TooManyRequests.create(
                        HttpStatus.TOO_MANY_REQUESTS,
                        "Too Many Requests",
                        HttpHeaders.EMPTY,
                        null,
                        null
                );
            }

            return responseBody;

        } catch (HttpClientErrorException.TooManyRequests e) {
            throw e;
        } catch (Exception e) {
            log.error("Error calling Pollinations.AI", e);
            throw new RuntimeException("Pollinations AI call failed: " + e.getMessage());
        }
    }

    /**
     * Fallback to Gemini
     */
    private String askAiWithFallback(String prompt) {
        try {
            log.info("Using fallback provider: {}", fallbackProvider);

            String response = switch (fallbackProvider.toLowerCase()) {
                case "gemini" -> askGemini(prompt);
                default -> throw new RuntimeException("Unknown fallback provider: " + fallbackProvider);
            };

            // Extract text from Gemini response
            return extractFromGeminiResponse(response);

        } catch (Exception e) {
            log.error("Fallback provider also failed", e);
            throw new RuntimeException("All AI providers failed");
        }
    }

    /**
     * Extract text from Gemini response
     */
    private String extractFromGeminiResponse(String response) {
        try {
            JsonNode root = objectMapper.readTree(response);

            // Navigate to candidates[0].content.parts[0].text
            if (root.has("candidates") && root.get("candidates").isArray() && root.get("candidates").size() > 0) {
                JsonNode firstCandidate = root.get("candidates").get(0);
                if (firstCandidate.has("content") && firstCandidate.get("content").has("parts")) {
                    JsonNode parts = firstCandidate.get("content").get("parts");
                    if (parts.isArray() && parts.size() > 0 && parts.get(0).has("text")) {
                        return parts.get(0).get("text").asText();
                    }
                }
            }

            return response;
        } catch (Exception e) {
            log.debug("Could not parse Gemini response", e);
            return response;
        }
    }

    /**
     * Gemini integration
     */
    private String askGemini(String prompt) {
        if (apiKey == null || apiKey.isBlank()) {
            throw new RuntimeException("API key required for Gemini provider");
        }

        String fullUrl = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=" + apiKey;

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        Map<String, Object> body = Map.of(
                "contents", List.of(
                        Map.of(
                                "parts", List.of(
                                        Map.of("text", prompt)
                                )
                        )
                )
        );

        HttpEntity<?> request = new HttpEntity<>(body, headers);

        try {
            String response = rest.postForObject(fullUrl, request, String.class);

            if (response == null || response.isBlank()) {
                throw new RuntimeException("Empty AI response from Gemini");
            }

            if (response.contains("RESOURCE_EXHAUSTED")
                    || response.contains("Quota exceeded")) {
                throw new RuntimeException("Gemini quota exceeded");
            }

            return response;

        } catch (Exception e) {
            log.error("Error calling Gemini", e);
            throw new RuntimeException("Gemini call failed: " + e.getMessage());
        }
    }

    /**
     * Check if we're currently rate limited
     */
    private boolean isRateLimited() {
        String key = provider;
        Instant resetTime = rateLimitReset.get(key);

        if (resetTime != null && resetTime.isAfter(Instant.now())) {
            return true;
        }

        AtomicInteger count = requestCounts.computeIfAbsent(key, k -> new AtomicInteger(0));

        // Pollinations free tier: ~30 requests per minute
        if (count.get() >= 25) {
            rateLimitReset.put(key, Instant.now().plus(Duration.ofSeconds(60)));
            return true;
        }

        return false;
    }

    /**
     * Track successful request
     */
    private void trackRequest() {
        String key = provider;
        AtomicInteger count = requestCounts.computeIfAbsent(key, k -> new AtomicInteger(0));
        count.incrementAndGet();

        // Reset counter after 60 seconds
        new Thread(() -> {
            try {
                Thread.sleep(60000);
                count.decrementAndGet();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }).start();
    }

    /**
     * Handle rate limit hit
     */
    private void handleRateLimit() {
        String key = provider;
        rateLimitReset.put(key, Instant.now().plus(Duration.ofSeconds(30)));
    }

    /**
     * Helper method to encode the prompt for URL
     */
    private String encodePrompt(String prompt) {
        return prompt.replace(" ", "%20")
                .replace("?", "%3F")
                .replace("&", "%26")
                .replace("=", "%3D")
                .replace("#", "%23")
                .replace("+", "%2B")
                .replace("/", "%2F")
                .replace(",", "%2C")
                .replace(";", "%3B")
                .replace(":", "%3A")
                .replace("@", "%40")
                .replace("$", "%24")
                .replace("\"", "%22")
                .replace("'", "%27");
    }

    /**
     * Get available Pollinations models
     */
    public List<String> getAvailableModels() {
        try {
            String modelsUrl = url + "/models";
            ResponseEntity<Map> response = rest.getForEntity(modelsUrl, Map.class);

            if (response.getBody() != null && response.getBody().containsKey("text")) {
                return (List<String>) response.getBody().get("text");
            }

            return List.of("openai", "openai-large", "openai-fast", "mistral", "gemini");

        } catch (Exception e) {
            log.warn("Could not fetch models, using defaults", e);
            return List.of("openai", "mistral", "gemini");
        }
    }

    /**
     * Simple method that returns only the content
     */
    public String askAiSimple(String prompt) {
        try {
            String response = askAi(prompt);
            return extractContentOnly(response);
        } catch (Exception e) {
            return "Error: " + e.getMessage();
        }
    }
}