package com.task.worker_service.entity;

public enum AiStatus {
    SUCCESS,
    FAILED
}
