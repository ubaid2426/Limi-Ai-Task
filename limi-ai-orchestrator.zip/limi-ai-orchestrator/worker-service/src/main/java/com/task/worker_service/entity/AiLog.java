package com.task.worker_service.entity;

//import com.task.worker_service.entity;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AiLog {

    @Id
    @GeneratedValue
    private Long id;

    private String username;

    @Column(length = 4000)
    private String prompt;

    @Column(length = 8000)
    private String response;

    @Enumerated(EnumType.STRING)
    private AiStatus status;   // ✅ ENUM instead of String

    private LocalDateTime createdAt;
}