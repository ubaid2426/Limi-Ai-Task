package com.task.worker_service.service;

import com.task.worker_service.ai.ExternalAiClient;
import com.task.worker_service.dto.AiRequestMessage;
import com.task.worker_service.entity.AiLog;
import com.task.worker_service.entity.AiStatus;
import com.task.worker_service.repository.AiLogRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class AiProcessingService {

    private final ExternalAiClient aiClient;
    private final AiLogRepository repo;

    public void process(AiRequestMessage msg) {

        AiLog log = new AiLog();
        log.setUsername(msg.getUsername());
        log.setPrompt(msg.getPrompt());
        log.setCreatedAt(LocalDateTime.now());

        try {

            String response = aiClient.askAi(msg.getPrompt());

            log.setResponse(response);
            log.setStatus(AiStatus.SUCCESS);

            System.out.println("AI SUCCESS");

        } catch (Exception e) {

            log.setResponse(e.getMessage());
            log.setStatus(AiStatus.FAILED);

            System.out.println("AI FAILED: " + e.getMessage());
        }

        repo.save(log);
    }
}

