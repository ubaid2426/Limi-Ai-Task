package com.task.worker_service.controller;

import com.task.worker_service.entity.AiLog;
import com.task.worker_service.entity.AiStatus;
import com.task.worker_service.repository.AiLogRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;


//@CrossOrigin(
//        origins = "http://localhost:5173",
//        methods = {RequestMethod.GET, RequestMethod.POST}
//)
@RestController
@RequestMapping("/admin")
@RequiredArgsConstructor
public class AdminController {

    private final AiLogRepository repo;

    @GetMapping("/logs")
    public List<AiLog> logs() {
        return repo.findAll();
    }

    @GetMapping("/stats")
    public Map<String, Object> stats() {

        long totalCalls = repo.count();

        long successCalls = repo.countByStatus(AiStatus.SUCCESS);

        long failedCalls = repo.countByStatus(AiStatus.FAILED);

        LocalDateTime startOfDay = LocalDateTime.now().toLocalDate().atStartOfDay();
        LocalDateTime endOfDay = startOfDay.plusDays(1);

        long todayCalls = repo.countByCreatedAtBetween(startOfDay, endOfDay);

        return Map.of(
                "totalCalls", totalCalls,
                "todayCalls", todayCalls,
                "successCalls", successCalls,
                "failedCalls", failedCalls
        );
    }
}

